﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace FakeDataApi.Controllers
{
    [ApiController]
    [Route("api/")]
    public class FakeDataController : ControllerBase
    {
        private MyList<Person> Persons { get; }

        public FakeDataController()
        {
            using var reader = new StreamReader("fakeData.json");

            string json = reader.ReadToEnd();

            Persons = JsonConvert.DeserializeObject<MyList<Person>>(json);

            Persons.OnAdd += AddPersonEvt;
        }

        [HttpGet]
        [Route("city/{filter}")]
        public IEnumerable<Person> GetPersonByFilter(string filter)
        {
            return Persons.Where(x => x.City == filter);
        }

        [HttpGet]
        [Route("surname/{surname}")]
        public IEnumerable<Person> GetPersonByFilterName(string surname)
        {
            return Persons.Where(x => x.LastName.EndsWith(surname));
        }

        [HttpPost]
        [Route("add")]
        public Person AddPerson(Person person)
        {
            Persons.Add(person);

            return person;
        }

        private void AddPersonEvt(object sender, EventArgs e)
        {
            string output = JsonConvert.SerializeObject(Persons, Formatting.Indented);

            System.IO.File.WriteAllText("fakeData.json", output);
        }
    }


    public class Person
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailAddress { get; set; }
        public string PhoneNumber { get; set; }
        public string Street { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string ZipCode { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Sex { get; set; }
        public string Company { get; set; }
        public string Department { get; set; }

        public override string ToString()
        {
            return $"{FirstName} {LastName} {EmailAddress} {PhoneNumber} {Street} {City} {State} {ZipCode} {DateOfBirth:dd/MM/yyyy} {Sex} {Company} {Department}";
        }
    }

    public class MyList<T> : List<T>
    {
        public event EventHandler OnAdd;

        public new void Add(T item)
        {
            base.Add(item);

            if (null != OnAdd)
            {
                OnAdd(item, null);
            }
        }
    }
}
